[[name_B]]と友達
